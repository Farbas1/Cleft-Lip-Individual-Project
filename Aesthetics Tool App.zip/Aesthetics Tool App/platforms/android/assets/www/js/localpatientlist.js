myFunction([
{"name":"Farbas Miah", "date":"7th November 2016 13:21:56", "image":"images/faces/face1.jpg"},
{"name":"James Miah", "date":"6th November 2016 13:21:56", "image":"images/faces/face2.jpg"},
{"name":"Paul Miah", "date":"5th November 2016 13:21:56", "image":"images/faces/face1.jpg"},
{"name":"Goldberg Miah", "date":"4th November 2016 13:21:56", "image":"images/faces/face2.jpg"},
])