#import <Cordova/CDVPlugin.h>

@interface BGSketchPlugin : CDVPlugin

- (void)getSketch:(CDVInvokedUrlCommand*)command;

@end
