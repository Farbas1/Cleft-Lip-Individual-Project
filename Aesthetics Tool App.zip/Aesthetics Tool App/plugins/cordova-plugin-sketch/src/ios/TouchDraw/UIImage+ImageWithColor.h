

@interface UIImage (ImageWithColor)
+ (UIImage *)imageWithColor:(UIColor *)color andSize:(CGRect)size;
@end
